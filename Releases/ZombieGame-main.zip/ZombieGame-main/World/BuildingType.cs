using System;
using System.Collections.Generic;
using ZombieGame.Common;

namespace ZombieGame.World
{
    public enum BuildingType
    {
        Shop,
        Bookstore,
        GunStore,
        GroceryStore,
        SportingGoodsStore,
        Home
    }
}
