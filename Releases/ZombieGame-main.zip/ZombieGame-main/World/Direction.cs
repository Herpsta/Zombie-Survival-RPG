using System;
using System.Collections.Generic;
using ZombieGame.Common;

namespace ZombieGame.World
{
    public enum Direction
    {
        North,
        South,
        East,
        West
    }
}
