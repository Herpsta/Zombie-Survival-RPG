using System;
using System.Collections.Generic;
using ZombieGame.Common;

namespace ZombieGame.World
{
    public class Building : Room
    {
        public BuildingType Type { get; set; }
        public List<Room> Rooms { get; set; }

        public Building(BuildingType type) : base()
        {
            Type = type;
            Rooms = new List<Room>();
        }
    }
}
