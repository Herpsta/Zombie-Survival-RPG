using System;
using System.Collections.Generic;
using ZombieGame.Entities;
using ZombieGame.Items;
using ZombieGame.World;
using ZombieGame.Common;

namespace ZombieGame.Utilities
{
    public static class Validator
    {
        public static bool ValidateGameEntity(GameEntity entity)
        {
            return entity.Health.CurrentValue >= 0 && entity.Hunger.CurrentValue >= 0 && entity.Oxygen.CurrentValue >= 0 && entity.Temperature.CurrentValue >= 0 && entity.Stamina.CurrentValue >= 0 && entity.Speed.CurrentValue >= 0;
        }

        public static bool ValidateRoom(Room room)
        {
            return room != null && room.Exits.Count > 0;
        }

        public static bool ValidateItem(BaseItem item)
        {
            return item != null && item.Stats != null && item.Stats.Count > 0;
        }
    }
}
