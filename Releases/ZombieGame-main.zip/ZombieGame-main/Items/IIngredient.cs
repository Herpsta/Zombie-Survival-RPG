using System;
using System.Collections.Generic;
using ZombieGame.Common;

namespace ZombieGame.Items
{
    public interface IIngredient
    {
        void Craft();
    }
}
